#include <iostream>

using namespace std;

#include "funkcjeAgh.h"
#include "aghFib.h"
